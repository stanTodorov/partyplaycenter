-- phpMyAdmin SQL Dump
-- version 3.4.9
-- http://www.phpmyadmin.net
--
-- Хост: localhost
-- Време на генериране: 
-- Версия на сървъра: 5.5.12
-- Версия на PHP: 5.3.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- База данни: `partycenter`
--

-- --------------------------------------------------------

--
-- Структура на таблица `albums`
--

DROP TABLE IF EXISTS `albums`;
CREATE TABLE IF NOT EXISTS `albums` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `club_id` tinyint(3) unsigned NOT NULL,
  `name` varchar(255) NOT NULL,
  `default_picture_id` int(10) unsigned NOT NULL,
  `added` datetime NOT NULL,
  `added_by` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8;

--
-- Ссхема на данните от таблица `albums`
--

INSERT INTO `albums` (`id`, `club_id`, `name`, `default_picture_id`, `added`, `added_by`) VALUES
(1, 2, 'dsfffffffffff', 1, '2012-02-13 14:17:49', 1),
(2, 2, 'ffffffffffffffffffffff', 3, '2012-02-13 14:18:18', 1),
(3, 2, 'aaaaaaaaaaaaa', 4, '2012-02-13 14:18:39', 1),
(4, 2, '11111111111111', 5, '2012-02-13 14:18:58', 1),
(5, 2, 'fffffffffffffffffff', 6, '2012-02-13 14:19:14', 1),
(6, 2, 'qweqweqwqwe', 7, '2012-02-13 14:19:33', 1),
(7, 2, 'ffffffffffffffffffffff', 8, '2012-02-13 14:19:44', 1),
(8, 2, 'aaaaaaaaaaaaaaa', 9, '2012-02-13 14:20:01', 1),
(9, 2, 'party yime', 10, '2012-02-13 14:20:13', 1),
(10, 1, 'sadasdasd', 11, '2012-02-13 14:46:34', 1),
(11, 1, 'dddddddddddddd', 12, '2012-02-13 14:46:48', 1),
(12, 1, 'sdfffffffff', 13, '2012-02-13 14:47:24', 1),
(13, 1, 'sdfffffffffff', 14, '2012-02-13 14:47:38', 1),
(14, 1, 'ffffffffffffffff', 15, '2012-02-13 14:47:49', 1),
(15, 1, 'qwdqwdqwdqwd', 16, '2012-02-13 14:48:52', 1),
(16, 1, 'ddddddddddasdasd', 17, '2012-02-13 14:49:05', 1),
(17, 1, 'ddddddddddddddd', 18, '2012-02-13 14:49:47', 1);

-- --------------------------------------------------------

--
-- Структура на таблица `albums_pictures`
--

DROP TABLE IF EXISTS `albums_pictures`;
CREATE TABLE IF NOT EXISTS `albums_pictures` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `album_id` int(10) unsigned NOT NULL,
  `image` varchar(255) NOT NULL,
  `thumb` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8;

--
-- Ссхема на данните от таблица `albums_pictures`
--

INSERT INTO `albums_pictures` (`id`, `album_id`, `image`, `thumb`) VALUES
(1, 1, 'enjoying_party_vector-1920x1200.jpg', 'thumbs/enjoying_party_vector-1920x1200.jpg'),
(2, 2, 'enjoying_party_vector-1920x1200.jpg', 'thumbs/enjoying_party_vector-1920x1200.jpg'),
(3, 2, '6a00d8341c4fe353ef01675ecb9416970b-800wi.jpg', 'thumbs/6a00d8341c4fe353ef01675ecb9416970b-800wi.jpg'),
(4, 3, 'FreeVector-Party-Silhouettes-Vectors.jpg', 'thumbs/FreeVector-Party-Silhouettes-Vectors.jpg'),
(5, 4, 'New-Years-Party.jpg', 'thumbs/New-Years-Party.jpg'),
(6, 5, 'Party-Party.jpg', 'thumbs/Party-Party.jpg'),
(7, 6, 'princess-birthday-party-pictures.jpg', 'thumbs/princess-birthday-party-pictures.jpg'),
(8, 7, 'surprise-party.s600x600.jpg', 'thumbs/surprise-party.s600x600.jpg'),
(9, 8, 'world-space-party-2007.jpg', 'thumbs/world-space-party-2007.jpg'),
(10, 9, 'party-salsa.jpg', 'thumbs/party-salsa.jpg'),
(11, 10, '303-Party-eecue_32606_b7qr_l.jpg', 'thumbs/303-Party-eecue_32606_b7qr_l.jpg'),
(12, 11, 'dope-jams-party-006.jpg', 'thumbs/dope-jams-party-006.jpg'),
(13, 12, 'dirty_dance_party.jpg', 'thumbs/dirty_dance_party.jpg'),
(14, 13, 'WG_Party.jpg', 'thumbs/WG_Party.jpg'),
(15, 14, 'princess-birthday-party-pictures.jpg', 'thumbs/princess-birthday-party-pictures.jpg'),
(16, 15, '794px-winter_2004_dreamhack_lan_party.jpg', 'thumbs/794px-winter_2004_dreamhack_lan_party.jpg'),
(17, 16, 'foam party_college.jpg', 'thumbs/foam party_college.jpg'),
(18, 17, 'party_bus_limo_1.jpg', 'thumbs/party_bus_limo_1.jpg'),
(19, 17, 'party_bus_limo_2.jpg', 'thumbs/party_bus_limo_2.jpg'),
(20, 17, 'pb6.jpg', 'thumbs/pb6.jpg'),
(21, 17, 'pb11.jpg', 'thumbs/pb11.jpg');

-- --------------------------------------------------------

--
-- Структура на таблица `clubs`
--

DROP TABLE IF EXISTS `clubs`;
CREATE TABLE IF NOT EXISTS `clubs` (
  `id` tinyint(3) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(60) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8;

--
-- Ссхема на данните от таблица `clubs`
--

INSERT INTO `clubs` (`id`, `name`) VALUES
(1, 'Party Play Center'),
(2, 'HiClub');

-- --------------------------------------------------------

--
-- Структура на таблица `events`
--

DROP TABLE IF EXISTS `events`;
CREATE TABLE IF NOT EXISTS `events` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `club_id` tinyint(3) unsigned NOT NULL,
  `comment` varchar(255) NOT NULL,
  `url` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL,
  `thumb` varchar(255) NOT NULL,
  `date` datetime NOT NULL,
  `added` datetime NOT NULL,
  `added_by` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8;

--
-- Ссхема на данните от таблица `events`
--

INSERT INTO `events` (`id`, `club_id`, `comment`, `url`, `image`, `thumb`, `date`, `added`, `added_by`) VALUES
(21, 2, 'sdfsdf', 'http://google.com', 'svatba.jpg', 'thumbs/svatba.jpg', '2012-02-17 00:00:00', '2012-02-10 14:59:19', 1),
(22, 2, 'asdasd', 'http://google.com/', 'poster.jpg', 'thumbs/poster.jpg', '2012-02-25 00:00:00', '2012-02-10 14:59:38', 1),
(23, 1, 'sdfsdfsdf', 'sdfsdfsdfsdfsdfsdf', 'FreeVector-Party-Silhouettes-Vectors.jpg', 'thumbs/FreeVector-Party-Silhouettes-Vectors.jpg', '2012-02-29 00:00:00', '2012-02-10 15:00:56', 1);

-- --------------------------------------------------------

--
-- Структура на таблица `menu`
--

DROP TABLE IF EXISTS `menu`;
CREATE TABLE IF NOT EXISTS `menu` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `category_id` smallint(5) unsigned NOT NULL,
  `image` varchar(255) NOT NULL,
  `thumb` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `comment` varchar(255) NOT NULL,
  `amount` varchar(64) NOT NULL,
  `price` decimal(8,2) NOT NULL,
  `added` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `added_by` int(10) unsigned NOT NULL DEFAULT '0',
  `modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified_by` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8;

--
-- Ссхема на данните от таблица `menu`
--

INSERT INTO `menu` (`id`, `category_id`, `image`, `thumb`, `name`, `comment`, `amount`, `price`, `added`, `added_by`, `modified`, `modified_by`) VALUES
(1, 1, 'news-seafood_pizza.jpg', 'thumbs/news-seafood_pizza.jpg', 'Мини пици', '', '1 бр.', 1.10, '2012-02-13 17:53:19', 0, '2012-02-14 13:32:38', 1),
(2, 1, '', '', 'Гондолки', 'Рибни, месни, зеленчукови', '1 бр.', 1.30, '2012-02-14 09:26:34', 0, '0000-00-00 00:00:00', 0),
(3, 2, 'kolbasi.jpg', 'thumbs/kolbasi.jpg', 'Плато сушено пушени колбаси', 'Филе Елена, суждук', '0,5 кг.', 25.00, '2012-02-14 09:48:27', 0, '2012-02-15 10:32:10', 1),
(4, 3, '20_08.jpg', 'thumbs/20_08.jpg', 'Петифури', '', '1 бр.', 1.00, '2012-02-14 09:49:13', 0, '2012-02-14 13:33:08', 1),
(15, 1, 'popcorn.jpg', 'thumbs/popcorn.jpg', 'Пуканки', '', '1 бр.', 2.00, '2012-02-14 18:04:45', 1, '2012-02-14 18:04:45', 1);

-- --------------------------------------------------------

--
-- Структура на таблица `menu_categories`
--

DROP TABLE IF EXISTS `menu_categories`;
CREATE TABLE IF NOT EXISTS `menu_categories` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(32) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8;

--
-- Ссхема на данните от таблица `menu_categories`
--

INSERT INTO `menu_categories` (`id`, `name`) VALUES
(1, 'Кетъринг'),
(2, 'Плата'),
(3, 'Десерти'),
(4, 'Безалкохолни');

-- --------------------------------------------------------

--
-- Структура на таблица `parties`
--

DROP TABLE IF EXISTS `parties`;
CREATE TABLE IF NOT EXISTS `parties` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `date` datetime NOT NULL,
  `content` text NOT NULL,
  `price` decimal(8,2) NOT NULL,
  `earnest` decimal(8,2) NOT NULL,
  `added` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `confirmed` tinyint(3) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8;

--
-- Ссхема на данните от таблица `parties`
--

INSERT INTO `parties` (`id`, `date`, `content`, `price`, `earnest`, `added`, `confirmed`) VALUES
(1, '2012-02-16 16:00:00', 'czoyNDczOiI8dHI+PHRoPtCY0LzQtTwvdGg+PHRkPtGM0Y/QsNGM0Y/QsNGM0Y/QsDwvdGQ+PC90cj48dHI+PHRoPtCi0LXQu9C10YTQvtC9PC90aD48dGQ+0YzRj9Cw0YzRj9Cw0YzRj9CwPC90ZD48L3RyPjx0cj48dGg+RS1tYWlsPC90aD48dGQ+YXNkQGFzZGFzZC5zYWQ8L3RkPjwvdHI+PHRyPjx0aD7QlNC10YLQtTwvdGg+PHRkPtGM0Y/QsNGM0Y/QsNGM0Y/QsCDQvdCwIDIg0LPQvtC00LjQvdC4PC90ZD48L3RyPjx0cj48dGg+0JHRgNC+0Lkg0LTQtdGG0LA8L3RoPjx0ZD4xPC90ZD48L3RyPjx0cj48dGg+0JfQvtC90LA8L3RoPjx0ZD7QlNC40YHQutC+0YLQtdC60LAgKyAxMDAg0LvQsi48L3RkPjwvdHI+PHRyPjx0aD7Qn9GA0L7QtNGK0LvQttC40YLQtdC70L3QvtGB0YI8L3RoPjx0ZD4zINGH0LDRgdCwOyA4INC70LIuL9C00LXRgtC1PC90ZD48L3RyPjx0cj48dGg+0JTQtdGC0YHQutC+INC80LXQvdGOPC90aD48dGQ+MiDQsdGALiDQvNC40L3QuCDRhdCw0LzQsdGD0YDQs9C10YDQuCwg0LHRg9GC0LXRgNC60LgsINGB0L7Qu9C10YLQuCwg0L3QsNGC0YPRgNCw0LvQtdC9INGB0L7Quiwg0LzQvtGA0LrQvtCy0Lgg4oCe0KTRgNC10YjigJw8L3RkPjwvdHI+PHRyPjx0aD7QotC10LzQsNGC0LjRh9C90L4g0L/QsNGA0YLQuDwvdGg+PHRkPtCf0LDRgNGC0Lgg0J/Qu9C10Lk8L3RkPjwvdHI+PHRyPjx0aD7Qn9GA0L7QtNGK0LvQttC40YLQtdC70L3QvtGB0YIg0YLQtdC80LDRgtC40YfQvdC+INC/0LDRgNGC0Lg8L3RoPjx0ZD4xLjMwINGHLiwgNjAg0LvQsi48L3RkPjwvdHI+PHRyPjx0aD7Qn9Cw0YDRgtC4INC/0LvQtdC5PC90aD48dGQ+0JjQvdC00LjQsNC90YHQutC+INC/0LDRgNGC0Lg8L3RkPjwvdHI+PHRyPjx0aD7QlNC10LrQvtGA0LDRhtC40Lg8L3RoPjx0ZD7QoSDRg9C60YDQsNGB0LA8L3RkPjwvdHI+PHRyPjx0aD7QmtC10YLRitGA0LjQvdCzPC90aD48dGQ+PHVsIGNsYXNzPSJjYXRlcmluZyI+PGxpPjxzcGFuIGNsYXNzPSJjYXQiPtCU0LXRgdC10YDRgtC4PC9zcGFuPjxzcGFuIGNsYXNzPSJuYW1lIj7Qn9C10YLQuNGE0YPRgNC4PC9zcGFuPjxzcGFuIGNsYXNzPSJhbW91bnQiPjEg0LHRgC48L3NwYW4+PHNwYW4gY2xhc3M9InByaWNlIj4xLDAwINC70LIuPC9zcGFuPjxzcGFuIGNsYXNzPSJjb3VudCI+IHggODwvc3Bhbj48c3BhbiBjbGFzcz0idG90YWwiPjgsMDAg0LvQsi48L3NwYW4+PC9saT48bGk+PHNwYW4gY2xhc3M9ImNhdCI+0JrQtdGC0YrRgNC40L3Qszwvc3Bhbj48c3BhbiBjbGFzcz0ibmFtZSI+0JPQvtC90LTQvtC70LrQuDxzbWFsbD4o0KDQuNCx0L3QuCwg0LzQtdGB0L3QuCwg0LfQtdC70LXQvdGH0YPQutC+0LLQuCk8L3NtYWxsPjwvc3Bhbj48c3BhbiBjbGFzcz0iYW1vdW50Ij4xINCx0YAuPC9zcGFuPjxzcGFuIGNsYXNzPSJwcmljZSI+MSwzMCDQu9CyLjwvc3Bhbj48c3BhbiBjbGFzcz0iY291bnQiPiB4IDE8L3NwYW4+PHNwYW4gY2xhc3M9InRvdGFsIj4xLDMwINC70LIuPC9zcGFuPjwvbGk+PGxpPjxzcGFuIGNsYXNzPSJjYXQiPtCa0LXRgtGK0YDQuNC90LM8L3NwYW4+PHNwYW4gY2xhc3M9Im5hbWUiPtCc0LjQvdC4INC/0LjRhtC4PC9zcGFuPjxzcGFuIGNsYXNzPSJhbW91bnQiPjEg0LHRgC48L3NwYW4+PHNwYW4gY2xhc3M9InByaWNlIj4xLDEwINC70LIuPC9zcGFuPjxzcGFuIGNsYXNzPSJjb3VudCI+IHggMTwvc3Bhbj48c3BhbiBjbGFzcz0idG90YWwiPjEsMTAg0LvQsi48L3NwYW4+PC9saT48bGk+PHNwYW4gY2xhc3M9ImNhdCI+0JrQtdGC0YrRgNC40L3Qszwvc3Bhbj48c3BhbiBjbGFzcz0ibmFtZSI+0J/Rg9C60LDQvdC60Lg8L3NwYW4+PHNwYW4gY2xhc3M9ImFtb3VudCI+MSDQsdGALjwvc3Bhbj48c3BhbiBjbGFzcz0icHJpY2UiPjIsMDAg0LvQsi48L3NwYW4+PHNwYW4gY2xhc3M9ImNvdW50Ij4geCAxPC9zcGFuPjxzcGFuIGNsYXNzPSJ0b3RhbCI+MiwwMCDQu9CyLjwvc3Bhbj48L2xpPjxsaT48c3BhbiBjbGFzcz0iY2F0Ij7Qn9C70LDRgtCwPC9zcGFuPjxzcGFuIGNsYXNzPSJuYW1lIj7Qn9C70LDRgtC+INGB0YPRiNC10L3QviDQv9GD0YjQtdC90Lgg0LrQvtC70LHQsNGB0Lg8c21hbGw+KNCk0LjQu9C1INCV0LvQtdC90LAsINGB0YPQttC00YPQuik8L3NtYWxsPjwvc3Bhbj48c3BhbiBjbGFzcz0iYW1vdW50Ij4wLDUg0LrQsy48L3NwYW4+PHNwYW4gY2xhc3M9InByaWNlIj4yNSwwMCDQu9CyLjwvc3Bhbj48c3BhbiBjbGFzcz0iY291bnQiPiB4IDU8L3NwYW4+PHNwYW4gY2xhc3M9InRvdGFsIj4xMjUsMDAg0LvQsi48L3NwYW4+PC9saT48L3VsPjwvdGQ+PC90cj48dHI+PHRoPtCi0L7RgNGC0LA8L3RoPjx0ZD7Rj9Cw0L7Rj9Cw0L7Rj9Cw0L48L3RkPjwvdHI+PHRyPjx0aD7QpNC+0YLQvtGB0LXRgdC40Y88L3RoPjx0ZD7Rj9Cw0L7Rj9Cw0L7Rj9Cw0L7RjzwvdGQ+PC90cj48dHI+PHRoPtCR0LXQu9C10LbQutCwPC90aD48dGQ+0LDQvtGP0LDQvtGP0LDRj9Cw0L7Rj9Cw0L48L3RkPjwvdHI+Ijs=', 305.40, 91.62, '2012-02-15 18:25:30', 0),
(3, '2012-02-16 10:00:00', 'czoyNDMzOiI8dHI+PHRoPtCY0LzQtTwvdGg+PHRkPmFzZGFzZDwvdGQ+PC90cj48dHI+PHRoPtCi0LXQu9C10YTQvtC9PC90aD48dGQ+YXNkYXNkYXM8L3RkPjwvdHI+PHRyPjx0aD5FLW1haWw8L3RoPjx0ZD5kQGFzZGFzZC5hc2Q8L3RkPjwvdHI+PHRyPjx0aD7QlNC10YLQtTwvdGg+PHRkPmFzZGFzZGFzZCDQvdCwIDEg0LPQvtC00LjQvdC4PC90ZD48L3RyPjx0cj48dGg+0JHRgNC+0Lkg0LTQtdGG0LA8L3RoPjx0ZD4xNjwvdGQ+PC90cj48dHI+PHRoPtCX0L7QvdCwPC90aD48dGQ+0KHQtdC/0LDRgNC10YLQsDwvdGQ+PC90cj48dHI+PHRoPtCf0YDQvtC00YrQu9C20LjRgtC10LvQvdC+0YHRgjwvdGg+PHRkPjMg0YfQsNGB0LA7IDEyINC70LIuL9C00LXRgtC1PC90ZD48L3RyPjx0cj48dGg+0JTQtdGC0YHQutC+INC80LXQvdGOPC90aD48dGQ+MiDQsdGALiDQvNC40L3QuCDRhdCw0LzQsdGD0YDQs9C10YDQuCwg0LHRg9GC0LXRgNC60LgsINGB0L7Qu9C10YLQuCwg0L3QsNGC0YPRgNCw0LvQtdC9INGB0L7Quiwg0LzQvtGA0LrQvtCy0Lgg4oCe0KTRgNC10YjigJw8L3RkPjwvdHI+PHRyPjx0aD7QotC10LzQsNGC0LjRh9C90L4g0L/QsNGA0YLQuDwvdGg+PHRkPtCW0LjQstC60L4g0JTRgNCw0LPQvtGB0YLQuNC90L7QsjwvdGQ+PC90cj48dHI+PHRoPtCf0YDQvtC00YrQu9C20LjRgtC10LvQvdC+0YHRgiDRgtC10LzQsNGC0LjRh9C90L4g0L/QsNGA0YLQuDwvdGg+PHRkPjEg0YcuLCA2MCDQu9CyLjwvdGQ+PC90cj48dHI+PHRoPtCf0LDRgNGC0Lgg0L/Qu9C10Lk8L3RoPjx0ZD7QpNC+0YDRgiDQkdC+0LnQsNGAIC8g0KHRitGA0LLQsNC50LLRitGAPC90ZD48L3RyPjx0cj48dGg+0JTQtdC60L7RgNCw0YbQuNC4PC90aD48dGQ+0KEg0YPQutGA0LDRgdCwPC90ZD48L3RyPjx0cj48dGg+0JrQtdGC0YrRgNC40L3QszwvdGg+PHRkPjx1bCBjbGFzcz0iY2F0ZXJpbmciPjxsaT48c3BhbiBjbGFzcz0iY2F0Ij7QlNC10YHQtdGA0YLQuDwvc3Bhbj48c3BhbiBjbGFzcz0ibmFtZSI+0J/QtdGC0LjRhNGD0YDQuDwvc3Bhbj48c3BhbiBjbGFzcz0iYW1vdW50Ij4xINCx0YAuPC9zcGFuPjxzcGFuIGNsYXNzPSJwcmljZSI+MSwwMCDQu9CyLjwvc3Bhbj48c3BhbiBjbGFzcz0iY291bnQiPiB4IDM8L3NwYW4+PHNwYW4gY2xhc3M9InRvdGFsIj4zLDAwINC70LIuPC9zcGFuPjwvbGk+PGxpPjxzcGFuIGNsYXNzPSJjYXQiPtCa0LXRgtGK0YDQuNC90LM8L3NwYW4+PHNwYW4gY2xhc3M9Im5hbWUiPtCT0L7QvdC00L7Qu9C60Lg8c21hbGw+KNCg0LjQsdC90LgsINC80LXRgdC90LgsINC30LXQu9C10L3Rh9GD0LrQvtCy0LgpPC9zbWFsbD48L3NwYW4+PHNwYW4gY2xhc3M9ImFtb3VudCI+MSDQsdGALjwvc3Bhbj48c3BhbiBjbGFzcz0icHJpY2UiPjEsMzAg0LvQsi48L3NwYW4+PHNwYW4gY2xhc3M9ImNvdW50Ij4geCAxNzwvc3Bhbj48c3BhbiBjbGFzcz0idG90YWwiPjIyLDEwINC70LIuPC9zcGFuPjwvbGk+PGxpPjxzcGFuIGNsYXNzPSJjYXQiPtCa0LXRgtGK0YDQuNC90LM8L3NwYW4+PHNwYW4gY2xhc3M9Im5hbWUiPtCc0LjQvdC4INC/0LjRhtC4PC9zcGFuPjxzcGFuIGNsYXNzPSJhbW91bnQiPjEg0LHRgC48L3NwYW4+PHNwYW4gY2xhc3M9InByaWNlIj4xLDEwINC70LIuPC9zcGFuPjxzcGFuIGNsYXNzPSJjb3VudCI+IHggMjwvc3Bhbj48c3BhbiBjbGFzcz0idG90YWwiPjIsMjAg0LvQsi48L3NwYW4+PC9saT48bGk+PHNwYW4gY2xhc3M9ImNhdCI+0JrQtdGC0YrRgNC40L3Qszwvc3Bhbj48c3BhbiBjbGFzcz0ibmFtZSI+0J/Rg9C60LDQvdC60Lg8L3NwYW4+PHNwYW4gY2xhc3M9ImFtb3VudCI+MSDQsdGALjwvc3Bhbj48c3BhbiBjbGFzcz0icHJpY2UiPjIsMDAg0LvQsi48L3NwYW4+PHNwYW4gY2xhc3M9ImNvdW50Ij4geCAzPC9zcGFuPjxzcGFuIGNsYXNzPSJ0b3RhbCI+NiwwMCDQu9CyLjwvc3Bhbj48L2xpPjxsaT48c3BhbiBjbGFzcz0iY2F0Ij7Qn9C70LDRgtCwPC9zcGFuPjxzcGFuIGNsYXNzPSJuYW1lIj7Qn9C70LDRgtC+INGB0YPRiNC10L3QviDQv9GD0YjQtdC90Lgg0LrQvtC70LHQsNGB0Lg8c21hbGw+KNCk0LjQu9C1INCV0LvQtdC90LAsINGB0YPQttC00YPQuik8L3NtYWxsPjwvc3Bhbj48c3BhbiBjbGFzcz0iYW1vdW50Ij4wLDUg0LrQsy48L3NwYW4+PHNwYW4gY2xhc3M9InByaWNlIj4yNSwwMCDQu9CyLjwvc3Bhbj48c3BhbiBjbGFzcz0iY291bnQiPiB4IDM8L3NwYW4+PHNwYW4gY2xhc3M9InRvdGFsIj43NSwwMCDQu9CyLjwvc3Bhbj48L2xpPjwvdWw+PC90ZD48L3RyPjx0cj48dGg+0KLQvtGA0YLQsDwvdGg+PHRkPnNkZnNmc2Rmc2RmPC90ZD48L3RyPjx0cj48dGg+0KTQvtGC0L7RgdC10YHQuNGPPC90aD48dGQ+c2Rmc2RmczwvdGQ+PC90cj48dHI+PHRoPtCR0LXQu9C10LbQutCwPC90aD48dGQ+ZGZzZGZzZGZmZmZmZmZmZmZmZmZmZmZmZmZmZjwvdGQ+PC90cj4iOw==', 360.30, 108.09, '2012-02-15 18:31:51', 0),
(10653, '2012-02-29 14:00:00', 'czoyMjIzOiI8dHI+PHRoPtCY0LzQtTwvdGg+PHRkPtCc0L7QtdGC0L4g0LjQvNC1PC90ZD48L3RyPjx0cj48dGg+0KLQtdC70LXRhNC+0L08L3RoPjx0ZD4wODggOCAxMjMtNDU2PC90ZD48L3RyPjx0cj48dGg+RS1tYWlsPC90aD48dGQ+bW9xYXRAZW1haWwuY29tPC90ZD48L3RyPjx0cj48dGg+0JTQtdGC0LU8L3RoPjx0ZD7Qn9C10L3Rh9C+INC90LAgOCDQs9C+0LTQuNC90Lg8L3RkPjwvdHI+PHRyPjx0aD7QkdGA0L7QuSDQtNC10YbQsDwvdGg+PHRkPjY8L3RkPjwvdHI+PHRyPjx0aD7Ql9C+0L3QsDwvdGg+PHRkPtCc0LDRgdC4PC90ZD48L3RyPjx0cj48dGg+0J/RgNC+0LTRitC70LbQuNGC0LXQu9C90L7RgdGCPC90aD48dGQ+MiDRh9Cw0YHQsDsgMTAg0LvQsi4v0LTQtdGC0LU8L3RkPjwvdHI+PHRyPjx0aD7QlNC10YLRgdC60L4g0LzQtdC90Y48L3RoPjx0ZD4yINCx0YAuINC80LjQvdC4INGF0LDQvNCx0YPRgNCz0LXRgNC4LCDQsdGD0YLQtdGA0LrQuCwg0YHQvtC70LXRgtC4LCDQvdCw0YLRg9GA0LDQu9C10L0g0YHQvtC6LCDQvNC+0YDQutC+0LLQuCDigJ7QpNGA0LXRiOKAnDwvdGQ+PC90cj48dHI+PHRoPtCi0LXQvNCw0YLQuNGH0L3QviDQv9Cw0YDRgtC4PC90aD48dGQ+0J/QsNGA0YLQuCDQn9C70LXQuTwvdGQ+PC90cj48dHI+PHRoPtCf0YDQvtC00YrQu9C20LjRgtC10LvQvdC+0YHRgiDRgtC10LzQsNGC0LjRh9C90L4g0L/QsNGA0YLQuDwvdGg+PHRkPjEuMzAg0YcuLCA2MCDQu9CyLjwvdGQ+PC90cj48dHI+PHRoPtCf0LDRgNGC0Lgg0L/Qu9C10Lk8L3RoPjx0ZD7Qn9GA0LDRgdGH0L4gKNCc0LXRh9C+INCf0YPRhSk8L3RkPjwvdHI+PHRyPjx0aD7QlNC10LrQvtGA0LDRhtC40Lg8L3RoPjx0ZD7QoSDRg9C60YDQsNGB0LA8L3RkPjwvdHI+PHRyPjx0aD7QmtC10YLRitGA0LjQvdCzPC90aD48dGQ+PHVsIGNsYXNzPSJjYXRlcmluZyI+PGxpPjxzcGFuIGNsYXNzPSJjYXQiPtCa0LXRgtGK0YDQuNC90LM8L3NwYW4+PHNwYW4gY2xhc3M9Im5hbWUiPtCT0L7QvdC00L7Qu9C60Lg8c21hbGw+KNCg0LjQsdC90LgsINC80LXRgdC90LgsINC30LXQu9C10L3Rh9GD0LrQvtCy0LgpPC9zbWFsbD48L3NwYW4+PHNwYW4gY2xhc3M9ImFtb3VudCI+MSDQsdGALjwvc3Bhbj48c3BhbiBjbGFzcz0icHJpY2UiPjEsMzAg0LvQsi48L3NwYW4+PHNwYW4gY2xhc3M9ImNvdW50Ij4geCAxPC9zcGFuPjxzcGFuIGNsYXNzPSJ0b3RhbCI+MSwzMCDQu9CyLjwvc3Bhbj48L2xpPjxsaT48c3BhbiBjbGFzcz0iY2F0Ij7QmtC10YLRitGA0LjQvdCzPC9zcGFuPjxzcGFuIGNsYXNzPSJuYW1lIj7QnNC40L3QuCDQv9C40YbQuDwvc3Bhbj48c3BhbiBjbGFzcz0iYW1vdW50Ij4xINCx0YAuPC9zcGFuPjxzcGFuIGNsYXNzPSJwcmljZSI+MSwxMCDQu9CyLjwvc3Bhbj48c3BhbiBjbGFzcz0iY291bnQiPiB4IDM8L3NwYW4+PHNwYW4gY2xhc3M9InRvdGFsIj4zLDMwINC70LIuPC9zcGFuPjwvbGk+PGxpPjxzcGFuIGNsYXNzPSJjYXQiPtCa0LXRgtGK0YDQuNC90LM8L3NwYW4+PHNwYW4gY2xhc3M9Im5hbWUiPtCf0YPQutCw0L3QutC4PC9zcGFuPjxzcGFuIGNsYXNzPSJhbW91bnQiPjEg0LHRgC48L3NwYW4+PHNwYW4gY2xhc3M9InByaWNlIj4yLDAwINC70LIuPC9zcGFuPjxzcGFuIGNsYXNzPSJjb3VudCI+IHggNDwvc3Bhbj48c3BhbiBjbGFzcz0idG90YWwiPjgsMDAg0LvQsi48L3NwYW4+PC9saT48bGk+PHNwYW4gY2xhc3M9ImNhdCI+0J/Qu9Cw0YLQsDwvc3Bhbj48c3BhbiBjbGFzcz0ibmFtZSI+0J/Qu9Cw0YLQviDRgdGD0YjQtdC90L4g0L/Rg9GI0LXQvdC4INC60L7Qu9Cx0LDRgdC4PHNtYWxsPijQpNC40LvQtSDQldC70LXQvdCwLCDRgdGD0LbQtNGD0LopPC9zbWFsbD48L3NwYW4+PHNwYW4gY2xhc3M9ImFtb3VudCI+MCw1INC60LMuPC9zcGFuPjxzcGFuIGNsYXNzPSJwcmljZSI+MjUsMDAg0LvQsi48L3NwYW4+PHNwYW4gY2xhc3M9ImNvdW50Ij4geCAyPC9zcGFuPjxzcGFuIGNsYXNzPSJ0b3RhbCI+NTAsMDAg0LvQsi48L3NwYW4+PC9saT48L3VsPjwvdGQ+PC90cj48dHI+PHRoPtCi0L7RgNGC0LA8L3RoPjx0ZD7Rg9GA0Lsg0LDQtNGA0LXRgTwvdGQ+PC90cj48dHI+PHRoPtCk0L7RgtC+0YHQtdGB0LjRjzwvdGg+PHRkPtGD0YDQuyDQsNC00YDQtdGBINGE0L7RgtC+0YHQtdGB0LjRjzwvdGQ+PC90cj48dHI+PHRoPtCR0LXQu9C10LbQutCwPC90aD48dGQ+0JrQvtC80LXQvdGC0LDRgNGK0YIg0LzQuDwvdGQ+PC90cj4iOw==', 182.60, 54.78, '2012-02-15 18:59:04', 0);

-- --------------------------------------------------------

--
-- Структура на таблица `settings`
--

DROP TABLE IF EXISTS `settings`;
CREATE TABLE IF NOT EXISTS `settings` (
  `name` varchar(255) NOT NULL,
  `value` varchar(255) NOT NULL,
  `default` varchar(255) NOT NULL,
  `type` enum('integer','string','boolean') NOT NULL,
  `description` varchar(255) NOT NULL,
  PRIMARY KEY (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Ссхема на данните от таблица `settings`
--

INSERT INTO `settings` (`name`, `value`, `default`, `type`, `description`) VALUES
('captcha.length', '4', '4', 'integer', 'Дължина на символите в кода за потвърждение Captcha (контакти)'),
('copyright', '2012', '2012', 'string', 'Година за авторски права'),
('date.fmt', 'd.m.Y H:i:s O', 'd.m.Y H:i:s O', 'string', 'Пълен формат на датата'),
('date.fmt.date', 'd.m.Y', 'd.m.Y', 'string', 'Формат на дата'),
('date.fmt.datefull', 'd.m.Y H:i:s', 'd.m.Y H:i:s', 'string', 'Пълен формат на датата, без часова зона'),
('date.fmt.datenice', 'D, d F Y H:i:s O', 'D, d F Y H:i:s O', 'string', 'Формат на датата с ден от седмицата и пълно име на месеца; часова зона'),
('date.fmt.datenicefull', 'd M Y H:i:s', 'd M Y H:i:s', 'string', 'Формат на датата с пълно име на месеца'),
('date.fmt.datetime', 'd.m.Y H:i', 'd.m.Y H:i', 'string', 'Дата и час'),
('date.fmt.time', 'H:i', 'H:i', 'string', 'Формат на часът, без секунди'),
('date.fmt.timefull', 'H:i:s', 'H:i:s', 'string', 'Формат на часът, пълен със секунди'),
('debug', 'true', 'false', 'boolean', 'Режим на дебъгване'),
('language', 'bg', 'bg', 'string', 'Език'),
('lastupdate', '1', '1', 'integer', 'Последна версия на CSS/JavaScript (кеш)'),
('login.timeout', '2700', '2700', 'integer', 'Време в секунди преди автоматичен изход от системата'),
('mail.contact', 'office@partyplaycenter.com', 'office@partyplaycenter.com', 'string', 'Мейл на който да се пращат писмата от контакт формуляра'),
('mail.contact.name', 'Office', 'Office', 'string', 'Мейл, име към mail.contact'),
('paging.count', '25', '25', 'integer', 'Странициране, брой резултати на страница.'),
('paging.groups', '7', '7', 'integer', 'Странициране, максимален брой на показаните страници наведнъж'),
('smtp.authtype', '', '', 'string', 'SMTP мейл, тип на удостоверяването (шифрована връзка)'),
('smtp.codepage', 'UTF-8', 'UTF-8', 'string', 'SMTP мейл, подразбираща се кодова таблица за мейлите'),
('smtp.frommail', 'noreply@partyplaycenter.com', 'noreply@partyplaycenter.com', 'string', 'SMTP мейл, изпращане на съобщения от този мейл адрес'),
('smtp.fromname', 'PartyPlay Center', 'PartyPlay Center', 'string', 'SMTP мейл, изпращане на съобщения с това име'),
('smtp.hostname', 'localhost', 'localhost', 'string', 'SMTP мейл, име на хост'),
('smtp.hostport', '25', '25', 'integer', 'SMTP мейл, порт за достъп'),
('smtp.is_auth', 'false', 'false', 'boolean', 'SMTP мейл, удостоверяване с парола и потребителско име'),
('smtp.password', '', '', 'string', 'SMTP мейл, Парола за удостоверяване'),
('smtp.username', '', '', 'string', 'SMTP мейл, Потребителско име за удостоверяване'),
('thumb.height', '110', '110', 'integer', 'Миниатюрни снимки, височина в пиксели'),
('thumb.width', '90', '90', 'integer', 'Миниатюрни снимки, ширина в пиксели');

-- --------------------------------------------------------

--
-- Структура на таблица `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `session_id` char(32) NOT NULL,
  `name` varchar(64) NOT NULL,
  `username` varchar(32) NOT NULL,
  `password` char(32) NOT NULL,
  `salt` char(10) NOT NULL,
  `added` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8;

--
-- Ссхема на данните от таблица `users`
--

INSERT INTO `users` (`id`, `session_id`, `name`, `username`, `password`, `salt`, `added`, `modified`) VALUES
(1, 'egb7n4a4qija3ji83ut5c2p0jeulabc1', 'Администратор', 'admin', 'f26c5f6eaaf9fa74c5ef0ae795a2b1af', 't\\cm!Fm@Z8', '0000-00-00 00:00:00', '2012-02-15 18:25:53');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
